/* jshint strict: false, unused: false */
/* global alert, Modernizr */

//console.log('\'Allo \'Allo!');

var alertFallback = false;
if (typeof console === 'undefined' || typeof console.log === 'undefined') {
    console = {};
    if (alertFallback) {
		console.log = function(msg) {
			alert(msg);
        };
	}else{
		console.log = function() {};
	}
}

var realConsoleLog = console.log;
console.log = function () {
    var message = [].join.call(arguments, ' ');
    // Display the message somewhere... (jQuery example)
    $('.consoleOutput').append('<p>'+message+'</p>');
    //.text($(".output").first().text() + "\n\n" + message); 
    
    realConsoleLog.apply(console, arguments);
};

function addPropertiesToTable(object, tableID)
{

	$.each(object, function(propertyName, valueOfProperty){
			if (object.hasOwnProperty(propertyName)) {
      			var obj = object[propertyName];
				
				if(typeof obj !== "function"){
	      			
	      			if(propertyName === "audio" || propertyName === "video" || propertyName === "input" || propertyName === "inputtypes" ){
	      				
	      				var newTable;
	      				switch (propertyName) {
						  case "audio":
						    newTable = '<table class="gridtable" id="audioTable"></table>';
						    $("#"+tableID).append("<tr><td>"+ propertyName +'</td><td>'+ newTable +"</td></tr>");
							addPropertiesToTable(obj, "audioTable");
						    break;
						  case "video":
						    newTable = '<table class="gridtable" id="videoTable"></table>';
						    $("#"+tableID).append("<tr><td>"+ propertyName +'</td><td>'+ newTable +"</td></tr>");
							addPropertiesToTable(obj, "videoTable");
						    break;
						  case "input":
						    newTable = '<table class="gridtable" id="inputTable"></table>';
						    $("#"+tableID).append("<tr><td>"+ propertyName +'</td><td>'+ newTable +"</td></tr>");
							addPropertiesToTable(obj, "inputTable");
						    break;
						  case "inputtypes":
						    newTable = '<table class="gridtable" id="inputtypesTable"></table>';
						    $("#"+tableID).append("<tr><td>"+ propertyName +'</td><td>'+ newTable +"</td></tr>");
							addPropertiesToTable(obj, "inputtypesTable");
						    break;
						  default:
						    newTable = '<table class="gridtable" class="randomTable"></table>';
						    $("#"+tableID).append("<tr><td>"+ propertyName +'</td><td>'+ newTable +"</td></tr>");
							addPropertiesToTable(obj, "randomTable");
						}
	      			}
	      			else if(obj === true)
	      			{
	      				$("#"+tableID).append("<tr><td>"+ propertyName +'</td><td class="true">'+ obj +"</td></tr>");	
	      			}
	      			else if(obj === false)
	      			{
	      				$("#"+tableID).append("<tr><td>"+ propertyName +'</td><td class="false">'+ obj +"</td></tr>");
	      			}
      			}
      			
   			}
		});
}

window.onload = function()
	{
		addPropertiesToTable(Modernizr, "featureTable");
		console.log("window.onload ist bis zum ende ausgeführt worden.");
	};
